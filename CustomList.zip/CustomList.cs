﻿using System;

namespace ImplementingList
{
    public class CustomList<T>
        where T: IComparable
    {
        private T[] array;

        public CustomList()
        {
        }

        public CustomList(int size)
        {
            array = new T[size];
        }

        public int Count { get; set; }

        public void Add(T element)
        {
            Count++;
            this.array = Resize();
            this.array[Count-1] = element;
            Console.WriteLine($"Added: {element}");
        }

        public void Insert(int index, T element)
        {
            Count++;

            array = Resize();

            T[] temp = new T[array.Length];
            // 1. fill before index
            for (int i = 0; i < index; i++)
            {
                temp[i] = array[i];
            }

            // 2. place the new element
            temp[index] = element;

            // 3. fill after index
            for (int i = index+1; i < Count; i++)
            {
                temp[i] = array[i - 1];
            }
            array = temp;
            Console.WriteLine($"Added: {element} at index {index}");
        }

        public void RemoveAt(int index)
        {
            Count--;
            if (Count > 0 && index <= Count)
            {
                T[] temp = new T[array.Length];

                // 1. fill before index
                for (int i = 0; i < index; i++)
                {
                    temp[i] = array[i];
                }

                // 2. remove the element
                // 3. fill after index
                for (int i = index; i < Count; i++)
                {
                    temp[i] = array[i + 1];
                }
                array = temp;
                Console.WriteLine($"RemovedAt: {index}");
            }
            else
            {
                Console.WriteLine("Index out of range");
            }
        }

        public void Remove(T element)
        {
            int index = IsElementExists(element);
            if (index != -1)
            {
                RemoveAt(index);
                Console.WriteLine($"Removed: {element}");
            }
            else
            {
                Console.WriteLine("Element doesn't exists");
            }
        }

        private int IsElementExists(T element)
        {
            for (int index = 0; index < Count; index++)
            {
                if (array[index].CompareTo(element) == 0)
                {
                     return index;
                }
            }
            return -1;
        }

        private T[] Resize()
        {
            if (array == null)
            {
                array = new T[4];
            }
            if (Count > this.array.Length)
            {
                T[] temp = new T[array.Length*2];
                for (int i = 0; i < array.Length; i++)
                {
                    temp[i] = array[i];
                }
                return temp;
            }

            return array;
        }
    }
}