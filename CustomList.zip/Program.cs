﻿using System;
using System.Collections.Generic;

namespace ImplementingList
{
    public class Program
    {
        static void Main(string[] args)
        {
            CustomList<int> mylist = new CustomList<int>();

            List<int> originalList = new List<int>();

            mylist.Add(3);
            mylist.Insert(0, 7);
            mylist.Insert(1, 4);
            mylist.Insert(3, 1);
            mylist.RemoveAt(0);
            mylist.Remove(4);
            mylist.Remove(10);
            mylist.RemoveAt(10);
            ;
        }
    }
}
